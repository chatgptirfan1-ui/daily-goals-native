# Daily Goals Android

Android wrapper for the original Daily Goals HTML tracker. The original HTML is bundled unchanged at `app/src/main/assets/index.html` and displayed in Android WebView with JavaScript and DOM storage enabled. LocalStorage data persists in the app's WebView profile.

Build: `gradle :app:assembleDebug` (JDK 17, Gradle 8.9).
